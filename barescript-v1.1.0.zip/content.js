(async () => {
  if (!location.href.startsWith("http://") && !location.href.startsWith("https://")) return;
  function notifyBodyReady() {
    chrome.runtime.sendMessage({ type: "BODY_READY", url: location.href });
  }
  if (document.body) {
    notifyBodyReady();
  } else {
    new MutationObserver((_, obs) => {
      if (document.body) {
        obs.disconnect();
        notifyBodyReady();
      }
    }).observe(document.documentElement, { childList: true });
  }
  window.addEventListener("pageshow", (e) => {
    if (e.persisted) {
      chrome.runtime.sendMessage({ type: "PAGE_RESTORED", url: location.href });
    }
  });
})();
