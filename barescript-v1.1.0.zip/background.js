import { i as isExtensionEnabled, b as getAllScripts, c as getLibraries } from "./assets/storage-B18s2dsF.js";
import { u as urlMatchesAnyPattern } from "./assets/matcher-Hauw0-xV.js";
registerDocumentStartScripts();
chrome.storage.onChanged.addListener((changes) => {
  if (changes.scripts) {
    registerDocumentStartScripts();
  }
});
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status !== "complete") return;
  const enabled = await isExtensionEnabled();
  if (!enabled) return;
  const url = tab.url;
  if (!url || !url.startsWith("http://") && !url.startsWith("https://")) {
    return;
  }
  await injectMatchingScripts(tabId, url, "document-end");
});
chrome.webNavigation.onHistoryStateUpdated.addListener(async (details) => {
  if (details.frameId !== 0) return;
  const enabled = await isExtensionEnabled();
  if (!enabled) return;
  const url = details.url;
  if (!url.startsWith("http://") && !url.startsWith("https://")) return;
  await injectDocumentStartScripts(details.tabId, url);
  await injectMatchingScripts(details.tabId, url, "document-end");
});
async function registerDocumentStartScripts() {
  try {
    const existing = await chrome.scripting.getRegisteredContentScripts();
    const bareScriptIds = existing.filter((s) => s.id.startsWith("barescript-")).map((s) => s.id);
    if (bareScriptIds.length > 0) {
      await chrome.scripting.unregisterContentScripts({ ids: bareScriptIds });
    }
    const enabled = await isExtensionEnabled();
    if (!enabled) return;
    const allScripts = await getAllScripts();
    const libraries = await getLibraries();
    const libraryMap = /* @__PURE__ */ new Map();
    for (const lib of libraries) {
      if (lib.enabled) {
        libraryMap.set(lib.name, lib);
      }
    }
    const startScripts = allScripts.filter(
      (s) => s.type !== "library" && s.enabled && s.runAt === "document-start" && s.matches.length > 0
    );
    await chrome.storage.local.set({
      _documentStartScripts: startScripts.map((s) => ({
        id: s.id,
        name: s.name,
        matches: s.matches,
        code: transformLibraryImports(s.code, libraryMap)
      }))
    });
    console.log(`[barescript] registered ${startScripts.length} document-start scripts`);
  } catch (error) {
    console.error("[barescript] failed to register document-start scripts:", error);
  }
}
async function injectMatchingScripts(tabId, url, runAt) {
  const allScripts = await getAllScripts();
  const libraries = await getLibraries();
  const matchingScripts = allScripts.filter(
    (script) => script.type !== "library" && script.enabled && (script.runAt || "document-end") === runAt && urlMatchesAnyPattern(url, script.matches)
  );
  const libraryMap = /* @__PURE__ */ new Map();
  for (const lib of libraries) {
    if (lib.enabled) {
      libraryMap.set(lib.name, lib);
    }
  }
  for (const script of matchingScripts) {
    await injectScript(tabId, script, libraryMap);
  }
}
function transformLibraryImports(code, libraryMap) {
  const inlineLibrary = (libName) => {
    const library = libraryMap.get(libName);
    if (!library) {
      console.warn(`[barescript] Library not found: ${libName}`);
      return null;
    }
    const libCode = library.code.replace(/export\s+default\s+/, "return ");
    return `(function() {
${libCode}
})()`;
  };
  let result = code;
  result = result.replace(
    /import\s+\{([^}]+)\}\s+from\s+['"]([^'"]+)['"]\s*;?/g,
    (_match, names, libName) => {
      const inlined = inlineLibrary(libName);
      if (!inlined) return `/* Library not found: ${libName} */`;
      return `const {${names}} = ${inlined};`;
    }
  );
  result = result.replace(
    /import\s+(\w+)\s+from\s+['"]([^'"]+)['"]\s*;?/g,
    (_match, varName, libName) => {
      const inlined = inlineLibrary(libName);
      if (!inlined) return `/* Library not found: ${libName} */`;
      return `const ${varName} = ${inlined};`;
    }
  );
  return result;
}
async function injectScript(tabId, script, libraryMap) {
  try {
    const cleanCode = transformLibraryImports(script.code, libraryMap);
    const wrappedCode = `
      (function() {
        console.log('[userscript:${script.name}] loaded');
        ${cleanCode}
      })();
    `;
    await chrome.scripting.executeScript({
      target: { tabId },
      func: (code) => new Function(code)(),
      args: [wrappedCode],
      world: "MAIN"
    });
  } catch (error) {
    console.error(`[userscript:${script.name}] injection failed:`, error);
  }
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  var _a, _b;
  if (message.type === "GET_MATCHING_SCRIPTS") {
    handleGetMatchingScripts(message.url).then(sendResponse);
    return true;
  }
  if (message.type === "BODY_READY" && ((_a = sender.tab) == null ? void 0 : _a.id)) {
    injectDocumentStartScripts(sender.tab.id, message.url);
  }
  if (message.type === "PAGE_RESTORED" && ((_b = sender.tab) == null ? void 0 : _b.id)) {
    injectMatchingScripts(sender.tab.id, message.url, "document-end");
  }
});
async function injectDocumentStartScripts(tabId, url) {
  const enabled = await isExtensionEnabled();
  if (!enabled) return;
  const { _documentStartScripts: scripts } = await chrome.storage.local.get("_documentStartScripts");
  if (!scripts || scripts.length === 0) return;
  for (const script of scripts) {
    if (urlMatchesAnyPattern(url, script.matches)) {
      const wrappedCode = `(function() {
        console.log('[userscript:${script.name}] loaded');
        ${script.code}
      })();`;
      try {
        await chrome.scripting.executeScript({
          target: { tabId },
          func: (code) => new Function(code)(),
          args: [wrappedCode],
          world: "MAIN"
        });
      } catch (e) {
        console.error(`[userscript:${script.name}] injection failed:`, e);
      }
    }
  }
}
async function handleGetMatchingScripts(url) {
  const scripts = await getAllScripts();
  return scripts.filter(
    (script) => script.type !== "library" && urlMatchesAnyPattern(url, script.matches)
  );
}
console.log("[barescript] background service worker started");
