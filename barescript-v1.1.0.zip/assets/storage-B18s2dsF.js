const DEFAULT_STORAGE = {
  scripts: {},
  enabled: true
};
async function getStorage() {
  const data = await chrome.storage.local.get(["scripts", "enabled"]);
  return {
    scripts: data.scripts ?? DEFAULT_STORAGE.scripts,
    enabled: data.enabled ?? DEFAULT_STORAGE.enabled
  };
}
async function setStorage(data) {
  await chrome.storage.local.set(data);
}
async function getAllScripts() {
  const { scripts } = await getStorage();
  return Object.values(scripts);
}
async function getLibraries() {
  const all = await getAllScripts();
  return all.filter((s) => s.type === "library");
}
async function saveScript(script) {
  const { scripts } = await getStorage();
  scripts[script.id] = script;
  await setStorage({ scripts });
}
async function deleteScript(id) {
  const { scripts } = await getStorage();
  delete scripts[id];
  await setStorage({ scripts });
}
async function isExtensionEnabled() {
  const { enabled } = await getStorage();
  return enabled;
}
async function setExtensionEnabled(enabled) {
  await setStorage({ enabled });
}
function generateId() {
  return crypto.randomUUID();
}
export {
  saveScript as a,
  getAllScripts as b,
  getLibraries as c,
  deleteScript as d,
  generateId as g,
  isExtensionEnabled as i,
  setExtensionEnabled as s
};
