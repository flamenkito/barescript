import { d, A, y, u, k, G } from "./hooks.module-QAf4_mlZ.js";
import { a as saveScript, g as generateId, d as deleteScript, b as getAllScripts } from "./storage-B18s2dsF.js";
import { p as parseMatchMetadata } from "./matcher-Hauw0-xV.js";
function Select({ options, value, onChange, class: className }) {
  const [isOpen, setIsOpen] = d(false);
  const ref = A(null);
  const selectedOption = options.find((o) => o.value === value);
  y(() => {
    function handleClickOutside(e) {
      if (ref.current && !ref.current.contains(e.target)) {
        setIsOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);
  function handleSelect(optionValue) {
    onChange(optionValue);
    setIsOpen(false);
  }
  function handleKeyDown(e) {
    if (e.key === "Escape") {
      setIsOpen(false);
    } else if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      setIsOpen(!isOpen);
    } else if (e.key === "ArrowDown" || e.key === "ArrowUp") {
      e.preventDefault();
      const currentIndex = options.findIndex((o) => o.value === value);
      const nextIndex = e.key === "ArrowDown" ? Math.min(currentIndex + 1, options.length - 1) : Math.max(currentIndex - 1, 0);
      onChange(options[nextIndex].value);
    }
  }
  return /* @__PURE__ */ u("div", { ref, class: `custom-select ${className || ""}`, children: [
    /* @__PURE__ */ u(
      "div",
      {
        class: `custom-select-trigger ${isOpen ? "open" : ""}`,
        onClick: () => setIsOpen(!isOpen),
        onKeyDown: handleKeyDown,
        tabIndex: 0,
        role: "combobox",
        "aria-expanded": isOpen,
        "aria-haspopup": "listbox",
        children: [
          /* @__PURE__ */ u("span", { children: (selectedOption == null ? void 0 : selectedOption.label) || "Select..." }),
          /* @__PURE__ */ u("span", { class: "custom-select-arrow" })
        ]
      }
    ),
    isOpen && /* @__PURE__ */ u("ul", { class: "custom-select-options", role: "listbox", children: options.map((option) => /* @__PURE__ */ u(
      "li",
      {
        class: `custom-select-option ${option.value === value ? "selected" : ""}`,
        onClick: () => handleSelect(option.value),
        role: "option",
        "aria-selected": option.value === value,
        children: option.label
      },
      option.value
    )) })
  ] });
}
function getMetaBlockRange(code) {
  const startMatch = code.match(/\/\/\s*==BareScript==/);
  const endMatch = code.match(/\/\/\s*==\/BareScript==/);
  if (!startMatch || !endMatch) return null;
  const start = startMatch.index;
  const end = endMatch.index + endMatch[0].length;
  return { start, end };
}
const JS_KEYWORDS = /\b(const|let|var|function|return|if|else|for|while|do|switch|case|break|continue|try|catch|finally|throw|new|this|class|extends|import|export|from|default|async|await|yield|typeof|instanceof|in|of|null|undefined|true|false)\b/g;
const JS_STRINGS = /(["'`])(?:(?!\1)[^\\]|\\.)*?\1/g;
const JS_COMMENTS = /(\/\/.*$|\/\*[\s\S]*?\*\/)/gm;
const JS_NUMBERS = /\b(\d+\.?\d*)\b/g;
function highlightJs(code) {
  const tokens = [];
  let match;
  while ((match = JS_COMMENTS.exec(code)) !== null) {
    tokens.push({
      start: match.index,
      end: match.index + match[0].length,
      html: `<span class="hl-comment">${escapeHtml(match[0])}</span>`
    });
  }
  JS_STRINGS.lastIndex = 0;
  while ((match = JS_STRINGS.exec(code)) !== null) {
    const inToken = tokens.some((t) => match.index >= t.start && match.index < t.end);
    if (!inToken) {
      tokens.push({
        start: match.index,
        end: match.index + match[0].length,
        html: `<span class="hl-string">${escapeHtml(match[0])}</span>`
      });
    }
  }
  tokens.sort((a, b) => a.start - b.start);
  let result = "";
  let lastEnd = 0;
  for (const token of tokens) {
    if (token.start > lastEnd) {
      result += highlightKeywordsAndNumbers(escapeHtml(code.slice(lastEnd, token.start)));
    }
    result += token.html;
    lastEnd = token.end;
  }
  if (lastEnd < code.length) {
    result += highlightKeywordsAndNumbers(escapeHtml(code.slice(lastEnd)));
  }
  return result;
}
function highlightKeywordsAndNumbers(escaped) {
  return escaped.replace(JS_KEYWORDS, '<span class="hl-keyword">$1</span>').replace(JS_NUMBERS, '<span class="hl-number">$1</span>');
}
function highlightCode(code) {
  const range = getMetaBlockRange(code);
  if (!range) {
    return highlightJs(code);
  }
  const before = highlightJs(code.slice(0, range.start));
  const meta = `<mark class="meta-highlight">${escapeHtml(code.slice(range.start, range.end))}</mark>`;
  const after = highlightJs(code.slice(range.end));
  return `${before}${meta}${after}`;
}
function escapeHtml(text) {
  return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function parseRunAt(code) {
  const match = code.match(/\/\/\s*@run-at\s+(.+)/);
  if (match) {
    const value = match[1].trim();
    if (value === "document-start" || value === "document-end") {
      return value;
    }
  }
  return null;
}
function updateMetadataBlock(code, name, matches, runAt, type) {
  const hasMetaBlock = code.includes("==BareScript==");
  if (!hasMetaBlock) {
    if (type === "library") {
      const metaBlock2 = `// ==BareScript==
// @name        ${name}
// @type        library
// ==/BareScript==

`;
      return metaBlock2 + code;
    }
    const matchLines = matches.map((m) => `// @match       ${m}`).join("\n");
    const metaBlock = `// ==BareScript==
// @name        ${name}
${matchLines}
// @run-at      ${runAt}
// ==/BareScript==

`;
    return metaBlock + code;
  }
  let updatedCode = code;
  if (updatedCode.match(/\/\/\s*@name\s+.+/)) {
    updatedCode = updatedCode.replace(/\/\/\s*@name\s+.+/, `// @name        ${name}`);
  } else {
    updatedCode = updatedCode.replace(/(\/\/\s*==BareScript==)/, `$1
// @name        ${name}`);
  }
  if (updatedCode.match(/\/\/\s*@type\s+.+/)) {
    updatedCode = updatedCode.replace(/\/\/\s*@type\s+.+/, `// @type        ${type}`);
  } else {
    updatedCode = updatedCode.replace(/(\/\/\s*@name\s+.+)/, `$1
// @type        ${type}`);
  }
  if (type === "library") {
    updatedCode = updatedCode.replace(/\/\/\s*@match\s+.+\n?/g, "");
    updatedCode = updatedCode.replace(/\/\/\s*@run-at\s+.+\n?/g, "");
  } else {
    if (updatedCode.match(/\/\/\s*@run-at\s+.+/)) {
      updatedCode = updatedCode.replace(/\/\/\s*@run-at\s+.+/, `// @run-at      ${runAt}`);
    } else {
      updatedCode = updatedCode.replace(/(\/\/\s*==\/BareScript==)/, `// @run-at      ${runAt}
$1`);
    }
    updatedCode = updatedCode.replace(/\/\/\s*@match\s+.+\n?/g, "");
    const matchLines = matches.map((m) => `// @match       ${m}`).join("\n");
    if (matchLines) {
      updatedCode = updatedCode.replace(/(\/\/\s*@type\s+.+)/, `$1
${matchLines}`);
    }
  }
  return updatedCode;
}
function ScriptEditor({ script, onSave, onCancel }) {
  const [name, setName] = d(script.name);
  const [type, setType] = d(script.type || "script");
  const [matches, setMatches] = d(script.matches);
  const [runAt, setRunAt] = d(script.runAt);
  const [code, setCode] = d(script.code);
  const [newMatch, setNewMatch] = d("");
  const backdropRef = A(null);
  const isLibrary = type === "library";
  function handleScroll(e) {
    const textarea = e.target;
    if (backdropRef.current) {
      backdropRef.current.scrollTop = textarea.scrollTop;
      backdropRef.current.scrollLeft = textarea.scrollLeft;
    }
  }
  function handleNameChange(newName) {
    setName(newName);
    setCode((prevCode) => updateMetadataBlock(prevCode, newName, matches, runAt, type));
  }
  function handleTypeChange(newType) {
    setType(newType);
    setCode((prevCode) => updateMetadataBlock(prevCode, name, matches, runAt, newType));
  }
  function handleAddMatch() {
    const trimmed = newMatch.trim();
    if (trimmed && !matches.includes(trimmed)) {
      const newMatches = [...matches, trimmed];
      setMatches(newMatches);
      setNewMatch("");
      setCode((prevCode) => updateMetadataBlock(prevCode, name, newMatches, runAt, type));
    }
  }
  function handleRemoveMatch(match) {
    const newMatches = matches.filter((m) => m !== match);
    setMatches(newMatches);
    setCode((prevCode) => updateMetadataBlock(prevCode, name, newMatches, runAt, type));
  }
  function handleRunAtChange(newRunAt) {
    setRunAt(newRunAt);
    setCode((prevCode) => updateMetadataBlock(prevCode, name, matches, newRunAt, type));
  }
  function handleCodeChange(e) {
    const newCode = e.target.value;
    setCode(newCode);
    const parsedMatches = parseMatchMetadata(newCode);
    if (parsedMatches.length > 0) {
      setMatches(parsedMatches);
    }
    const nameMatch = newCode.match(/\/\/\s*@name\s+(.+)/);
    if (nameMatch) {
      setName(nameMatch[1].trim());
    }
    const typeMatch = newCode.match(/\/\/\s*@type\s+(.+)/);
    if (typeMatch) {
      const parsedType = typeMatch[1].trim();
      if (parsedType === "library" || parsedType === "script") {
        setType(parsedType);
      }
    }
    const parsedRunAt = parseRunAt(newCode);
    if (parsedRunAt) {
      setRunAt(parsedRunAt);
    }
  }
  function handleSave() {
    const updated = {
      ...script,
      name,
      type,
      matches: isLibrary ? [] : matches,
      runAt,
      code,
      updatedAt: Date.now()
    };
    onSave(updated);
  }
  function handleKeyDown(e) {
    if (e.key === "Enter") {
      e.preventDefault();
      handleAddMatch();
    }
  }
  return /* @__PURE__ */ u("div", { class: "editor", children: [
    /* @__PURE__ */ u("header", { class: "editor-header", children: [
      /* @__PURE__ */ u("h2", { class: "editor-title", children: [
        /* @__PURE__ */ u("img", { src: "/icons/icon48.png", alt: "BareScript", width: "24", height: "24" }),
        "Edit ",
        isLibrary ? "Library" : "Script"
      ] }),
      /* @__PURE__ */ u("div", { class: "editor-actions", children: [
        /* @__PURE__ */ u("button", { class: "btn-secondary", onClick: onCancel, children: "Cancel" }),
        /* @__PURE__ */ u("button", { class: "btn-primary", onClick: handleSave, children: "Save" })
      ] })
    ] }),
    /* @__PURE__ */ u("div", { class: "form-group", children: [
      /* @__PURE__ */ u("label", { class: "form-label", children: "Name" }),
      /* @__PURE__ */ u(
        "input",
        {
          type: "text",
          class: "form-input",
          value: name,
          onInput: (e) => handleNameChange(e.target.value)
        }
      ),
      isLibrary && /* @__PURE__ */ u("div", { class: "form-hint", children: [
        "Import in scripts: ",
        /* @__PURE__ */ u("code", { children: [
          "import ",
          name.replace(/-/g, ""),
          " from '",
          name,
          "';"
        ] })
      ] })
    ] }),
    /* @__PURE__ */ u("div", { class: "form-group", children: [
      /* @__PURE__ */ u("label", { class: "form-label", children: "Type" }),
      /* @__PURE__ */ u(
        Select,
        {
          options: [
            { value: "script", label: "Script" },
            { value: "library", label: "Library" }
          ],
          value: type,
          onChange: (value) => handleTypeChange(value)
        }
      )
    ] }),
    !isLibrary && /* @__PURE__ */ u(k, { children: [
      /* @__PURE__ */ u("div", { class: "form-group", children: [
        /* @__PURE__ */ u("label", { class: "form-label", children: "Match Patterns" }),
        /* @__PURE__ */ u("div", { class: "matches-list", children: matches.map((match) => /* @__PURE__ */ u("span", { class: "match-tag", children: [
          match,
          /* @__PURE__ */ u("span", { class: "match-remove", onClick: () => handleRemoveMatch(match), children: "×" })
        ] }, match)) }),
        /* @__PURE__ */ u("div", { class: "match-input-row", children: [
          /* @__PURE__ */ u(
            "input",
            {
              type: "text",
              placeholder: "https://example.com/*",
              value: newMatch,
              onInput: (e) => setNewMatch(e.target.value),
              onKeyDown: handleKeyDown
            }
          ),
          /* @__PURE__ */ u("button", { class: "btn-secondary", onClick: handleAddMatch, children: "Add" })
        ] })
      ] }),
      /* @__PURE__ */ u("div", { class: "form-group", children: [
        /* @__PURE__ */ u("label", { class: "form-label", children: "Run At" }),
        /* @__PURE__ */ u(
          Select,
          {
            options: [
              { value: "document-end", label: "Document End" },
              { value: "document-start", label: "Document Start" }
            ],
            value: runAt,
            onChange: (value) => handleRunAtChange(value)
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ u("div", { class: "form-group", children: [
      /* @__PURE__ */ u("label", { class: "form-label", children: "Code" }),
      /* @__PURE__ */ u("div", { class: "code-editor", children: [
        /* @__PURE__ */ u(
          "pre",
          {
            ref: backdropRef,
            class: "code-backdrop",
            dangerouslySetInnerHTML: { __html: highlightCode(code) + "\n\n" }
          }
        ),
        /* @__PURE__ */ u(
          "textarea",
          {
            class: "code-textarea",
            value: code,
            onInput: handleCodeChange,
            onScroll: handleScroll,
            spellcheck: false
          }
        )
      ] })
    ] })
  ] });
}
function Dashboard() {
  const [scripts, setScripts] = d([]);
  const [editingScript, setEditingScript] = d(null);
  y(() => {
    loadScripts();
  }, []);
  async function loadScripts() {
    const all = await getAllScripts();
    setScripts(all.sort((a, b) => b.updatedAt - a.updatedAt));
  }
  function handleNewScript() {
    const newScript = {
      id: generateId(),
      name: "New Script",
      enabled: true,
      type: "script",
      matches: ["*://*/*"],
      runAt: "document-end",
      code: `// ==BareScript==
// @name        New Script
// @type        script
// @match       *://*/*
// @run-at      document-end
// ==/BareScript==

console.log('Hello from BareScript!');
`,
      updatedAt: Date.now()
    };
    setEditingScript(newScript);
  }
  function handleNewLibrary() {
    const newLibrary = {
      id: generateId(),
      name: "my-library",
      enabled: true,
      type: "library",
      matches: [],
      runAt: "document-end",
      code: `// ==BareScript==
// @name        my-library
// @type        library
// ==/BareScript==

// Usage: import MyLib from 'my-library';
export default {
  greet(name) {
    return 'Hello, ' + name + '!';
  }
};
`,
      updatedAt: Date.now()
    };
    setEditingScript(newLibrary);
  }
  async function handleSave(script) {
    await saveScript(script);
    setEditingScript(null);
    await loadScripts();
  }
  function handleCancel() {
    setEditingScript(null);
  }
  async function handleDelete(id) {
    if (confirm("Are you sure you want to delete this script?")) {
      await deleteScript(id);
      await loadScripts();
    }
  }
  async function handleToggle(script) {
    const updated = { ...script, enabled: !script.enabled, updatedAt: Date.now() };
    await saveScript(updated);
    await loadScripts();
  }
  if (editingScript) {
    return /* @__PURE__ */ u("div", { class: "dashboard", children: /* @__PURE__ */ u(ScriptEditor, { script: editingScript, onSave: handleSave, onCancel: handleCancel }) });
  }
  return /* @__PURE__ */ u("div", { class: "dashboard", children: [
    /* @__PURE__ */ u("header", { class: "dashboard-header", children: /* @__PURE__ */ u("div", { class: "dashboard-title", children: [
      /* @__PURE__ */ u("img", { src: "/icons/icon48.png", alt: "BareScript", width: "32", height: "32" }),
      "BareScript"
    ] }) }),
    /* @__PURE__ */ u("div", { class: "scripts-header", children: [
      /* @__PURE__ */ u("h2", { class: "scripts-title", children: "Scripts & Libraries" }),
      /* @__PURE__ */ u("div", { class: "header-actions", children: [
        /* @__PURE__ */ u("button", { class: "btn-primary", onClick: handleNewScript, children: "+ New Script" }),
        /* @__PURE__ */ u("button", { class: "btn-secondary", onClick: handleNewLibrary, children: "+ New Library" })
      ] })
    ] }),
    scripts.length === 0 ? /* @__PURE__ */ u("div", { class: "empty-state", children: [
      /* @__PURE__ */ u("p", { children: "No scripts yet" }),
      /* @__PURE__ */ u("button", { class: "btn-primary", onClick: handleNewScript, children: "Create your first script" })
    ] }) : scripts.map((script) => /* @__PURE__ */ u("div", { class: "script-card", children: [
      /* @__PURE__ */ u("div", { class: "script-info", children: [
        /* @__PURE__ */ u("div", { class: "script-card-name", children: [
          script.name,
          /* @__PURE__ */ u("span", { class: `type-badge ${script.type === "library" ? "type-library" : "type-script"}`, children: script.type === "library" ? "Library" : "Script" })
        ] }),
        /* @__PURE__ */ u("div", { class: "script-card-matches", children: script.type === "library" ? `import ${script.name.replace(/-/g, "")} from '${script.name}';` : script.matches.join(", ") })
      ] }),
      /* @__PURE__ */ u("div", { class: "script-actions", children: [
        /* @__PURE__ */ u(
          "div",
          {
            class: `toggle ${script.enabled ? "active" : ""}`,
            onClick: () => handleToggle(script),
            role: "switch",
            "aria-checked": script.enabled
          }
        ),
        /* @__PURE__ */ u("button", { class: "btn-secondary", onClick: () => setEditingScript(script), children: "Edit" }),
        /* @__PURE__ */ u("button", { class: "btn-danger", onClick: () => handleDelete(script.id), children: "Delete" })
      ] })
    ] }, script.id))
  ] });
}
G(/* @__PURE__ */ u(Dashboard, {}), document.getElementById("app"));
