function matchPatternToRegex(pattern) {
  try {
    if (pattern === "<all_urls>") {
      return /^https?:\/\/.*/;
    }
    const match = pattern.match(/^(\*|https?):\/\/(\*|(?:\*\.)?[^/]+)(\/.*)?$/);
    if (!match) {
      return null;
    }
    const [, scheme, host, path = "/*"] = match;
    let regexStr = "^";
    if (scheme === "*") {
      regexStr += "https?";
    } else {
      regexStr += escapeRegex(scheme);
    }
    regexStr += ":\\/\\/";
    if (host === "*") {
      regexStr += "[^/]+";
    } else if (host.startsWith("*.")) {
      const baseDomain = escapeRegex(host.slice(2));
      regexStr += `(?:[^/]+\\.)?${baseDomain}`;
    } else {
      regexStr += escapeRegex(host);
    }
    const pathRegex = escapeRegex(path).replace(/\\\*/g, ".*");
    regexStr += pathRegex;
    regexStr += "$";
    return new RegExp(regexStr);
  } catch {
    return null;
  }
}
function escapeRegex(str) {
  return str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function urlMatchesPattern(url, pattern) {
  const regex = matchPatternToRegex(pattern);
  if (!regex) {
    return false;
  }
  return regex.test(url);
}
function urlMatchesAnyPattern(url, patterns) {
  return patterns.some((pattern) => urlMatchesPattern(url, pattern));
}
function parseMatchMetadata(code) {
  const matches = [];
  const lines = code.split("\n");
  let inMetaBlock = false;
  for (const line of lines) {
    const trimmed = line.trim();
    if (trimmed.includes("==BareScript==")) {
      inMetaBlock = true;
      continue;
    }
    if (trimmed.includes("==/BareScript==")) {
      break;
    }
    if (inMetaBlock) {
      const matchResult = trimmed.match(/\/\/\s*@match\s+(.+)/);
      if (matchResult) {
        matches.push(matchResult[1].trim());
      }
    }
  }
  return matches;
}
export {
  parseMatchMetadata as p,
  urlMatchesAnyPattern as u
};
