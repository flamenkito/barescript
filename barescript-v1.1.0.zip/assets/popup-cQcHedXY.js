import { d, y, u, G } from "./hooks.module-QAf4_mlZ.js";
import { i as isExtensionEnabled, s as setExtensionEnabled, a as saveScript } from "./storage-B18s2dsF.js";
function Popup() {
  const [enabled, setEnabled] = d(true);
  const [scripts, setScripts] = d([]);
  const [currentUrl, setCurrentUrl] = d("");
  y(() => {
    loadState();
  }, []);
  async function loadState() {
    const ext = await isExtensionEnabled();
    setEnabled(ext);
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab == null ? void 0 : tab.url) {
      setCurrentUrl(tab.url);
      const matchingScripts = await chrome.runtime.sendMessage({
        type: "GET_MATCHING_SCRIPTS",
        url: tab.url
      });
      setScripts(matchingScripts || []);
    }
  }
  async function handleToggleExtension() {
    const newState = !enabled;
    await setExtensionEnabled(newState);
    setEnabled(newState);
  }
  async function handleToggleScript(script) {
    const updated = { ...script, enabled: !script.enabled, updatedAt: Date.now() };
    await saveScript(updated);
    setScripts(scripts.map((s) => s.id === script.id ? updated : s));
  }
  function openDashboard() {
    chrome.tabs.create({ url: chrome.runtime.getURL("src/dashboard/dashboard.html") });
  }
  const hostname = currentUrl ? new URL(currentUrl).hostname : "";
  return /* @__PURE__ */ u("div", { class: "popup", children: [
    /* @__PURE__ */ u("header", { class: "popup-header", children: [
      /* @__PURE__ */ u("div", { class: "popup-title", children: [
        /* @__PURE__ */ u("img", { src: "/icons/icon48.png", alt: "BareScript", width: "24", height: "24" }),
        "BareScript"
      ] }),
      /* @__PURE__ */ u(
        "div",
        {
          class: `toggle ${enabled ? "active" : ""}`,
          onClick: handleToggleExtension,
          role: "switch",
          "aria-checked": enabled
        }
      )
    ] }),
    scripts.length > 0 ? /* @__PURE__ */ u("div", { class: "script-list", children: [
      /* @__PURE__ */ u("div", { class: "script-list-title", children: hostname || "Scripts" }),
      scripts.map((script) => /* @__PURE__ */ u("div", { class: "script-item", children: [
        /* @__PURE__ */ u("span", { class: "script-name", children: script.name }),
        /* @__PURE__ */ u(
          "div",
          {
            class: `toggle ${script.enabled ? "active" : ""}`,
            onClick: () => handleToggleScript(script),
            role: "switch",
            "aria-checked": script.enabled
          }
        )
      ] }, script.id))
    ] }) : /* @__PURE__ */ u("div", { class: "no-scripts", children: [
      /* @__PURE__ */ u("svg", { class: "no-scripts-icon", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", "stroke-width": "1.5", children: /* @__PURE__ */ u("path", { d: "M9 12h6m-3-3v6m-7 4h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" }) }),
      "No scripts for this page"
    ] }),
    /* @__PURE__ */ u("footer", { class: "popup-footer", children: /* @__PURE__ */ u("a", { class: "dashboard-link", onClick: openDashboard, children: "Dashboard" }) })
  ] });
}
G(/* @__PURE__ */ u(Popup, {}), document.getElementById("app"));
